#############################################################################
#__________       ___.        ___________           .__                     #  
#\______   \_____ \_ |__ _____\__    ___/___   ____ |  |   ______           #
# |    |  _/\__  \ | __ \\__  \ |    | /  _ \ /  _ \|  |  /  ___/           #
# |    |   \ / __ \| \_\ \/ __ \|    |(  <_> |  <_> )  |__\___ \            #
# |______  /(____  /___  (____  /____| \____/ \____/|____/____  >           #
#        \/      \/    \/     \/                              \/            #
#############################################################################
#              Unpack the whole folder with all files inlcuded!             #
#		    Do not move the dll and exe files                       #     
#  Open Executabalbe file from same folder where the other files is placed  #
#  									    #
#             Delete Tool files, re-download to solve your problems.        #
#	       or un-Plug/re-Plug Wifi/Lan, restart Computer/Laptop         #
#             Contact our support if still need help with our tools.        #
#                             www.BabaTools.com                             #
#                             www.BabaTools.Net                             #
#############################################################################
